'use strict';
// Almacén en memoria: sirve para probar el sistema SIN SQL Server (modo demo: STORE=memory).
// Los datos se pierden al apagar el servidor.
module.exports = async function memoryStore() {
  const T = {}, tomb = new Map(), users = [];
  let seq = 0, uid = 0;
  const tb = e => (T[e] ??= new Map());
  return {
    kind: 'memoria',
    async init() {},
    async tx(fn) { return fn(null); },
    async list(e, since = 0) {
      const out = [];
      for (const [k, r] of tb(e)) if (r.t > since) out.push({ k, d: JSON.parse(r.d) });
      return out;
    },
    async get(e, k) { const r = tb(e).get(String(k)); return r ? JSON.parse(r.d) : null; },
    async upsert(e, k, o, t) { tb(e).set(String(k), { d: JSON.stringify(o), t }); tomb.delete(e + '\0' + k); },
    async del(e, k, t) { tb(e).delete(String(k)); tomb.set(e + '\0' + k, { e, k: String(k), t }); },
    async tombs(since = 0) { return [...tomb.values()].filter(x => x.t > since).map(({ e, k }) => ({ e, k })); },
    async nextId() { return ++seq; },
    async countUsers() { return users.length; },
    async userById(id) { return users.find(u => u.id === +id) || null; },
    async userByName(n) { return users.find(u => u.u === n) || null; },
    async users() { return users.map(({ h, ...u }) => u); },
    async addUser({ u, n, r, h }) {
      if (users.some(x => x.u === u)) throw Object.assign(new Error('dup'), { dup: true });
      const x = { id: ++uid, u, n, r, h, v: Date.now() }; users.push(x); return x.id;
    },
    async setUser(id, { u, n, h }) {
      const x = users.find(z => z.id === +id); if (!x) return;
      if (u && u !== x.u && users.some(z => z.u === u)) throw Object.assign(new Error('dup'), { dup: true });
      if (u) x.u = u; if (n) x.n = n; if (h) x.h = h; x.v = Date.now() + Math.random();
    },
    async delUser(id) { const i = users.findIndex(z => z.id === +id); if (i >= 0) users.splice(i, 1); }
  };
};
