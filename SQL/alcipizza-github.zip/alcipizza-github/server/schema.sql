-- Alcipizza · Esquema de base de datos para SQL Server (2012 o superior / Azure SQL)
-- El servidor lo ejecuta solo al arrancar. Es idempotente: se puede ejecutar varias veces.
-- Cada tabla guarda columnas consultables (para reportes en SSMS) y la fila completa en "Datos" (JSON).

IF OBJECT_ID('dbo.Config','U') IS NULL
CREATE TABLE dbo.Config(
  Clave NVARCHAR(40) NOT NULL CONSTRAINT PK_Config PRIMARY KEY,
  Datos NVARCHAR(MAX) NOT NULL,
  Actualizado BIGINT NOT NULL);
GO
IF OBJECT_ID('dbo.Platos','U') IS NULL
CREATE TABLE dbo.Platos(
  Id BIGINT NOT NULL CONSTRAINT PK_Platos PRIMARY KEY,
  Nombre NVARCHAR(120) NULL,
  Categoria NVARCHAR(60) NULL,
  Datos NVARCHAR(MAX) NOT NULL,
  Actualizado BIGINT NOT NULL);
GO
IF OBJECT_ID('dbo.Extras','U') IS NULL
CREATE TABLE dbo.Extras(
  Id BIGINT NOT NULL CONSTRAINT PK_Extras PRIMARY KEY,
  Nombre NVARCHAR(120) NULL,
  Insumo NVARCHAR(120) NULL,
  Precio DECIMAL(18,2) NULL,
  Datos NVARCHAR(MAX) NOT NULL,
  Actualizado BIGINT NOT NULL);
GO
IF OBJECT_ID('dbo.Insumos','U') IS NULL
CREATE TABLE dbo.Insumos(
  Nombre NVARCHAR(120) NOT NULL CONSTRAINT PK_Insumos PRIMARY KEY,
  Tipo NVARCHAR(1) NULL,
  Unidad NVARCHAR(10) NULL,
  Stock DECIMAL(18,3) NULL,
  Surtidor NVARCHAR(40) NULL,
  Datos NVARCHAR(MAX) NOT NULL,
  Actualizado BIGINT NOT NULL);
GO
IF OBJECT_ID('dbo.Surtidores','U') IS NULL
CREATE TABLE dbo.Surtidores(
  Id BIGINT NOT NULL CONSTRAINT PK_Surtidores PRIMARY KEY,
  Nombre NVARCHAR(120) NULL,
  Empresa NVARCHAR(120) NULL,
  Correo NVARCHAR(120) NULL,
  Telefono NVARCHAR(40) NULL,
  Datos NVARCHAR(MAX) NOT NULL,
  Actualizado BIGINT NOT NULL);
GO
IF OBJECT_ID('dbo.Compras','U') IS NULL
CREATE TABLE dbo.Compras(
  Clave NVARCHAR(200) NOT NULL CONSTRAINT PK_Compras PRIMARY KEY,
  Fecha DATETIME2(3) NULL,
  Producto NVARCHAR(120) NULL,
  Cantidad DECIMAL(18,3) NULL,
  Unidad NVARCHAR(10) NULL,
  Costo DECIMAL(18,2) NULL,
  Surtidor NVARCHAR(40) NULL,
  Registro NVARCHAR(80) NULL,
  Datos NVARCHAR(MAX) NOT NULL,
  Actualizado BIGINT NOT NULL);
GO
IF NOT EXISTS (SELECT 1 FROM sys.sequences WHERE name = 'SeqPedido')
CREATE SEQUENCE dbo.SeqPedido AS INT START WITH 1 INCREMENT BY 1;
GO
IF OBJECT_ID('dbo.Pedidos','U') IS NULL
CREATE TABLE dbo.Pedidos(
  Id INT NOT NULL CONSTRAINT PK_Pedidos PRIMARY KEY,
  Fecha DATETIME2(3) NULL,
  Origen NVARCHAR(10) NULL,
  Mesera NVARCHAR(50) NULL,
  Destino NVARCHAR(100) NULL,
  Cliente NVARCHAR(100) NULL,
  Telefono NVARCHAR(30) NULL,
  Total DECIMAL(18,2) NULL,
  Estado NVARCHAR(20) NULL,
  PagoEstado NVARCHAR(20) NULL,
  MetodoPago NVARCHAR(60) NULL,
  Token NVARCHAR(60) NULL,
  Datos NVARCHAR(MAX) NOT NULL,
  Actualizado BIGINT NOT NULL);
GO
IF OBJECT_ID('dbo.Bitacora','U') IS NULL
CREATE TABLE dbo.Bitacora(
  Clave NVARCHAR(200) NOT NULL CONSTRAINT PK_Bitacora PRIMARY KEY,
  Fecha DATETIME2(3) NULL,
  Usuario NVARCHAR(50) NULL,
  Nombre NVARCHAR(80) NULL,
  Accion NVARCHAR(400) NULL,
  Datos NVARCHAR(MAX) NOT NULL,
  Actualizado BIGINT NOT NULL);
GO
IF OBJECT_ID('dbo.Usuarios','U') IS NULL
CREATE TABLE dbo.Usuarios(
  Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Usuarios PRIMARY KEY,
  Usuario NVARCHAR(50) NOT NULL CONSTRAINT UQ_Usuarios_Usuario UNIQUE,
  Nombre NVARCHAR(80) NOT NULL,
  Rol NVARCHAR(1) NOT NULL,
  ClaveHash NVARCHAR(300) NOT NULL,
  Actualizado BIGINT NOT NULL);
GO
IF OBJECT_ID('dbo.Eliminados','U') IS NULL
CREATE TABLE dbo.Eliminados(
  Entidad NVARCHAR(20) NOT NULL,
  Clave NVARCHAR(200) NOT NULL,
  Fecha BIGINT NOT NULL,
  CONSTRAINT PK_Eliminados PRIMARY KEY (Entidad, Clave));
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Platos_Act' AND object_id = OBJECT_ID('dbo.Platos'))
CREATE INDEX IX_Platos_Act ON dbo.Platos(Actualizado);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Extras_Act' AND object_id = OBJECT_ID('dbo.Extras'))
CREATE INDEX IX_Extras_Act ON dbo.Extras(Actualizado);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Insumos_Act' AND object_id = OBJECT_ID('dbo.Insumos'))
CREATE INDEX IX_Insumos_Act ON dbo.Insumos(Actualizado);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Surtidores_Act' AND object_id = OBJECT_ID('dbo.Surtidores'))
CREATE INDEX IX_Surtidores_Act ON dbo.Surtidores(Actualizado);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Compras_Act' AND object_id = OBJECT_ID('dbo.Compras'))
CREATE INDEX IX_Compras_Act ON dbo.Compras(Actualizado);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Compras_Fecha' AND object_id = OBJECT_ID('dbo.Compras'))
CREATE INDEX IX_Compras_Fecha ON dbo.Compras(Fecha);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Pedidos_Act' AND object_id = OBJECT_ID('dbo.Pedidos'))
CREATE INDEX IX_Pedidos_Act ON dbo.Pedidos(Actualizado);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Pedidos_Fecha' AND object_id = OBJECT_ID('dbo.Pedidos'))
CREATE INDEX IX_Pedidos_Fecha ON dbo.Pedidos(Fecha);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Bitacora_Act' AND object_id = OBJECT_ID('dbo.Bitacora'))
CREATE INDEX IX_Bitacora_Act ON dbo.Bitacora(Actualizado);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Eliminados_Fecha' AND object_id = OBJECT_ID('dbo.Eliminados'))
CREATE INDEX IX_Eliminados_Fecha ON dbo.Eliminados(Fecha);
GO
