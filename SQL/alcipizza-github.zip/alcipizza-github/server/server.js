'use strict';
/* Alcipizza · Servidor
 * API REST + archivos de la página. Guarda todo en SQL Server (o en memoria con STORE=memory).
 * © ING. JOSÉ LUIS ARIZA */
require('dotenv').config();
const path = require('path');
const crypto = require('crypto');
const express = require('express');

const PORT = +process.env.PORT || 3000;
const SECRET = process.env.TOKEN_SECRET || '';
if (SECRET.length < 24) { console.error('✖ Falta TOKEN_SECRET en .env (mínimo 24 caracteres aleatorios).'); process.exit(1); }

let store;
const ROOT = path.join(__dirname, '..');
const http = (status, error) => Object.assign(new Error(error), { status });
const ah = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

/* ---------- Contraseñas y sesiones ---------- */
const scrypt = (pw, salt) => new Promise((ok, no) => crypto.scrypt(pw, salt, 64, (e, k) => (e ? no(e) : ok(k))));
async function hashPw(pw) { const s = crypto.randomBytes(16).toString('hex'); return `s1$${s}$${(await scrypt(pw, s)).toString('hex')}`; }
const DUMMY = `s1$${'0'.repeat(32)}$${'0'.repeat(128)}`;
async function checkPw(pw, h) {
  const [v, s, x] = String(h || DUMMY).split('$');
  const a = await scrypt(pw, s || '0'), b = Buffer.from(x || '', 'hex');
  return v === 's1' && a.length === b.length && crypto.timingSafeEqual(a, b);
}
const b64 = b => Buffer.from(b).toString('base64url');
const mac = s => crypto.createHmac('sha256', SECRET).update(s).digest('base64url');
const sign = u => { const p = b64(JSON.stringify({ id: u.id, v: u.v, exp: Date.now() + 12 * 36e5 })); return p + '.' + mac(p); };
function verify(t) {
  const [p, m] = String(t || '').split('.');
  if (!p || !m) return null;
  const good = mac(p);
  if (m.length !== good.length || !crypto.timingSafeEqual(Buffer.from(m), Buffer.from(good))) return null;
  try { const o = JSON.parse(Buffer.from(p, 'base64url').toString()); return o.exp > Date.now() ? o : null; } catch (e) { return null; }
}
const safeEq = (a, b) => a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));

/* ---------- Límite de intentos (en memoria) ---------- */
const hits = new Map();
function limit(key, max, ms) {
  const now = Date.now(), a = (hits.get(key) || []).filter(t => now - t < ms);
  if (a.length >= max) throw http(429, 'Demasiados intentos. Espera unos minutos.');
  a.push(now); hits.set(key, a);
}
setInterval(() => { const now = Date.now(); for (const [k, a] of hits) if (!a.some(t => now - t < 36e5)) hits.delete(k); }, 6e5).unref();

/* ---------- Auxiliares ---------- */
const subActive = async () => { const s = await store.get('sub', 'sub'); return !!(s && s.on && s.hasta > Date.now()); };
async function addLog(x) {
  const t = Date.now(), i = crypto.randomBytes(3).toString('hex');
  await store.upsert('logs', `${t}-${i}`, { t, i, ...x }, t);
}
const checkKey = k => { if (typeof k !== 'string' || !k || k.length > 200) throw http(400, 'Clave inválida'); };
const USER_RE = /^[a-z0-9._-]{3,30}$/;
function cleanUser(b, { needPass }) {
  const out = {};
  if (b.u != null) { out.u = String(b.u).trim().toLowerCase(); if (!USER_RE.test(out.u)) throw http(400, 'Usuario: 3 a 30 caracteres (letras, números, punto, guion).'); }
  if (b.n != null) { out.n = String(b.n).trim().slice(0, 60); if (!out.n) throw http(400, 'El nombre no puede quedar vacío'); }
  if (b.p != null && b.p !== '') { out.p = String(b.p); if (out.p.length < 6) throw http(400, 'La contraseña debe tener mínimo 6 caracteres.'); }
  if (needPass && !out.p) throw http(400, 'Escribe una contraseña (mínimo 6 caracteres).');
  return out;
}

/* ---------- Catálogo y precios (el servidor recalcula, nunca confía en el navegador) ---------- */
async function priceItems(it, tx) {
  if (!Array.isArray(it) || !it.length || it.length > 40) throw http(400, 'El pedido está vacío o es demasiado grande');
  const P = new Map((await store.list('platos', 0, tx)).map(r => [String(r.k), r.d]));
  const X = (await store.list('extras', 0, tx)).map(r => r.d);
  const S = new Set((await store.list('ins', 0, tx)).filter(r => r.d.k === 's').map(r => r.k));
  let total = 0;
  const items = it.map(c => {
    const p = P.get(String(c && c.id));
    if (!p) throw http(400, 'Hay un plato que ya no está disponible');
    const v = p.v.find(z => z.t === c.v);
    if (!v) throw http(400, 'Hay un tamaño que ya no está disponible');
    const xs = (Array.isArray(c.xs) ? c.xs : []).map(z => {
      const e = X.find(x => x.n === z.n && (p.ex || []).includes(x.id));
      if (!e) throw http(400, 'Hay un extra que ya no está disponible');
      return { n: e.n, ins: e.ins, q: e.q, u: e.u, p: e.p };
    });
    const price = v.p + xs.reduce((a, e) => a + e.p, 0);
    total += price;
    return {
      id: p.id, e: p.e, n: p.n, v: v.t, p: price, xs,
      q: (Array.isArray(c.q) ? c.q : []).map(String).filter(k => k in p.i),
      sa: (Array.isArray(c.sa) ? c.sa : []).map(String).filter(k => S.has(k)),
      nota: String(c.nota || '').slice(0, 200)
    };
  });
  return { items, total };
}

/* ---------- Seguridad / CORS ---------- */
const app = express();
app.disable('x-powered-by');
app.set('trust proxy', process.env.TRUST_PROXY === '1');
app.use((req, res, next) => {
  res.set({ 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'SAMEORIGIN', 'Referrer-Policy': 'same-origin' });
  if (req.path.startsWith('/api/')) {
    res.set('Cache-Control', 'no-store');
    const o = process.env.CORS_ORIGIN;
    if (o) {
      res.set({ 'Access-Control-Allow-Origin': o, 'Vary': 'Origin', 'Access-Control-Allow-Headers': 'Authorization, Content-Type', 'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS' });
      if (req.method === 'OPTIONS') return res.sendStatus(204);
    }
  }
  next();
});

const auth = (...roles) => ah(async (req, res, next) => {
  const p = verify((req.headers.authorization || '').replace(/^Bearer /, ''));
  const u = p && await store.userById(p.id);
  if (!u || u.v !== p.v) throw http(401, 'Sesión vencida. Entra de nuevo.');
  if (roles.length && !roles.includes(u.r)) throw http(403, 'No tienes permiso para esto');
  req.user = u; next();
});
const optAuth = ah(async (req, res, next) => {
  if (!req.headers.authorization) return next();
  return auth()(req, res, next);
});

/* ---------- Rutas públicas ---------- */
app.get('/api/health', (q, s) => s.json({ ok: true, almacen: store.kind }));

app.post('/api/login', express.json({ limit: '4kb' }), ah(async (req, res) => {
  const u = String(req.body.u || '').trim().toLowerCase(), p = String(req.body.p || '');
  limit(`login|${req.ip}|${u}`, 8, 10 * 60 * 1000);
  const x = await store.userByName(u);
  const ok = await checkPw(p, x && x.h);          // siempre se calcula, exista o no el usuario
  if (!x || !ok) throw http(401, 'Usuario o contraseña incorrectos');
  if (x.r !== 'x' && !(await subActive())) throw http(403, 'El servicio está suspendido. Contacta al desarrollador.');
  await addLog({ u: x.u, n: x.n, a: 'Ingresó al sistema' });
  res.json({ token: sign(x), id: x.id, r: x.r, u: x.u, n: x.n });
}));

const PUB = ['platos', 'extras', 'cfg', 'sub'];
const minSalsa = r => ({ k: r.d.k, d: { k: 's', u: r.d.u, s: 1, c: 1 } });

async function collect(role, since) {
  const rows = {}, set = role === 'a' ? ['platos', 'extras', 'ins', 'sur', 'compras', 'pedidos', 'logs', 'cfg', 'sub'] : role === 'm' ? [...PUB, 'ins', 'pedidos'] : [...PUB, 'ins'];
  for (const e of set) {
    let r = await store.list(e, since);
    if (e === 'ins' && role !== 'a') r = r.filter(x => x.d.k === 's').map(x => ({ k: x.k, d: minSalsa(x).d }));
    rows[e] = r;
  }
  const del = (await store.tombs(since)).filter(x => set.includes(x.e));
  return { t: Date.now(), rows, del };
}
app.get('/api/public', ah(async (req, res) => res.json(await collect('p', Math.max(0, +req.query.since || 0)))));
app.get('/api/sync', auth('a', 'm', 'x'), ah(async (req, res) => res.json(await collect(req.user.r, Math.max(0, +req.query.since || 0)))));

app.get('/api/pedidos/:id', ah(async (req, res) => {
  limit(`ped-get|${req.ip}`, 240, 60 * 1000);
  const o = await store.get('pedidos', req.params.id);
  const tk = String(req.query.tk || '');
  if (!o || !o.tk || !tk || !safeEq(o.tk, tk)) throw http(404, 'Pedido no encontrado');
  res.json(o);
}));

app.post('/api/pedidos', express.json({ limit: '64kb' }), optAuth, ah(async (req, res) => {
  const b = req.body || {}, staff = !!req.user && ['m', 'a'].includes(req.user.r);
  if (req.user && !staff) throw http(403, 'Este usuario no puede crear pedidos');
  if (!staff) { limit(`pedido|${req.ip}`, 12, 10 * 60 * 1000); if (!(await subActive())) throw http(403, 'El servicio está en pausa'); }
  const cfg = (await store.get('cfg', 'cfg')) || {}, mesas = +cfg.mesas || 0, d = String(b.d || '');
  const n = +((d.match(/(\d+)$/) || [])[1] || 0);
  const okDest = staff ? (d === 'Domicilio' || (/^Mesa \d+$/.test(d) && n >= 1 && n <= mesas))
    : (d === 'Domicilio' || d === 'Recoger en local' || (/^En el local · Mesa \d+$/.test(d) && n >= 1 && n <= mesas));
  if (!okDest) throw http(400, 'Destino no válido');
  const nom = String(b.nom || '').trim().slice(0, 100), dir = String(b.dir || '').trim().slice(0, 200), tel = String(b.tel || '').trim().slice(0, 30);
  if ((!staff || d === 'Domicilio') && !nom) throw http(400, 'Escribe el nombre');
  if (d === 'Domicilio' && !dir) throw http(400, 'Escribe la dirección');
  if (tel && !/^[0-9+()\s-]+$/.test(tel)) throw http(400, 'Teléfono no válido');
  let mp = '';
  if (!staff) {
    const m = Object.values(cfg.pay || {}).find(x => x.on && x.n === b.mp);
    if (!m) throw http(400, 'Método de pago no disponible');
    mp = m.n;
  }
  const { items, total } = await priceItems(b.it);
  const id = await store.nextId('pedidos');
  const o = {
    id, t: Date.now(), o: staff ? 'mesera' : 'web', m: staff ? req.user.u : null, d, nom,
    dir: d === 'Domicilio' ? dir : '', tel: (d === 'Domicilio' || d === 'Recoger en local') ? tel : '',
    it: items, tot: total, est: 'nuevo', pg: 'pendiente', mp
  };
  if (!staff) o.tk = crypto.randomBytes(12).toString('hex');
  await store.upsert('pedidos', id, o, Date.now());
  if (!staff) await addLog({ u: 'cliente', n: 'Cliente web', a: `Envió pedido #${id} · ${d} · $${total}` });
  res.status(201).json(o);
}));

/* ---------- Rutas con sesión ---------- */
app.use(express.json({ limit: '8mb' }));

app.post('/api/logout', auth(), ah(async (req, res) => { await addLog({ u: req.user.u, n: req.user.n, a: 'Cerró sesión' }); res.json({ ok: true }); }));

const PUSH = { a: ['platos', 'extras', 'ins', 'sur', 'compras', 'pedidos', 'logs', 'cfg'], m: ['pedidos', 'logs'], x: ['sub', 'logs'] };
const DELE = { a: ['platos', 'extras', 'ins', 'sur', 'compras'], m: [], x: [] };
const ESTADOS = ['nuevo', 'preparando', 'listo', 'entregado', 'cancelado'];

async function mergeOrder(k, d, tx) {
  const old = await store.get('pedidos', k, tx);
  if (!old) throw http(404, 'El pedido no existe');
  const n = { ...d, id: old.id, t: old.t, o: old.o, m: old.m };
  if (old.tk) n.tk = old.tk; else delete n.tk;
  if (JSON.stringify(d.it) !== JSON.stringify(old.it)) { const r = await priceItems(d.it, tx); n.it = r.items; n.tot = r.total; }
  else { n.it = old.it; n.tot = old.tot; }
  if (!ESTADOS.includes(n.est)) throw http(400, 'Estado no válido');
  return n;
}

app.post('/api/push', auth('a', 'm', 'x'), ah(async (req, res) => {
  const { changes = [], deletes = [] } = req.body || {}, r = req.user.r, now = Date.now();
  if (!Array.isArray(changes) || !Array.isArray(deletes) || changes.length > 500 || deletes.length > 500) throw http(413, 'Demasiados cambios a la vez');
  await store.tx(async tx => {
    for (const c of changes) {
      if (!PUSH[r].includes(c.e)) throw http(403, 'No tienes permiso para modificar: ' + c.e);
      checkKey(c.k);
      let d = c.d;
      if (!d || typeof d !== 'object' || Array.isArray(d)) throw http(400, 'Dato inválido');
      if (c.e === 'logs') d = { ...d, u: req.user.u, n: req.user.n };            // la bitácora no se puede falsificar
      else if (c.e === 'sub') {
        if (!(d.on === 0 || d.on === 1) || !Number.isFinite(d.hasta)) throw http(400, 'Suscripción no válida');
        d = { on: d.on, hasta: d.hasta };
      } else if (c.e === 'pedidos') d = await mergeOrder(c.k, d, tx);
      else if (c.e === 'cfg' && typeof d.n !== 'string') throw http(400, 'Configuración no válida');
      await store.upsert(c.e, c.k, d, now, tx);
    }
    for (const x of deletes) {
      if (!DELE[r].includes(x.e)) throw http(403, 'No tienes permiso para borrar: ' + x.e);
      checkKey(x.k);
      await store.del(x.e, x.k, now, tx);
    }
  });
  res.json({ ok: true, t: now });
}));

/* ---------- Usuarios ---------- */
const canTouch = (me, t) => me.r === 'x' || (me.r === 'a' && (t.id === me.id || t.r === 'm'));
app.get('/api/usuarios', auth('a', 'x'), ah(async (req, res) => {
  const all = await store.users();
  res.json(req.user.r === 'x' ? all : all.filter(u => u.id === req.user.id || u.r === 'm'));
}));
app.post('/api/usuarios', auth('a', 'x'), ah(async (req, res) => {
  const c = cleanUser(req.body || {}, { needPass: true });
  if (!c.u || !c.n) throw http(400, 'Completa nombre, usuario y contraseña');
  try { const id = await store.addUser({ u: c.u, n: c.n, r: 'm', h: await hashPw(c.p) }); await addLog({ u: req.user.u, n: req.user.n, a: `Creó la mesera ${c.n}` }); res.status(201).json({ id }); }
  catch (e) { throw e.dup ? http(409, 'Ese usuario ya existe') : e; }
}));
app.put('/api/usuarios/:id', auth('a', 'x'), ah(async (req, res) => {
  const t = await store.userById(req.params.id);
  if (!t || !canTouch(req.user, t)) throw http(t ? 403 : 404, t ? 'No tienes permiso' : 'Usuario no encontrado');
  const c = cleanUser(req.body || {}, {}), up = {};
  if (c.u) up.u = c.u; if (c.n) up.n = c.n; if (c.p) up.h = await hashPw(c.p);
  if (!Object.keys(up).length) throw http(400, 'No hay nada que cambiar');
  try { await store.setUser(t.id, up); } catch (e) { throw e.dup ? http(409, 'Ese usuario ya existe') : e; }
  await addLog({ u: req.user.u, n: req.user.n, a: `Cambió ${up.h ? 'la contraseña' : 'los datos'} de ${t.n} (${t.u})` });
  const out = { ok: true };
  if (t.id === req.user.id) out.token = sign(await store.userById(t.id));        // no cerrar su propia sesión
  res.json(out);
}));
app.delete('/api/usuarios/:id', auth('a', 'x'), ah(async (req, res) => {
  const t = await store.userById(req.params.id);
  if (!t || t.r !== 'm') throw http(404, 'Solo se pueden quitar meseras');
  await store.delUser(t.id);
  await addLog({ u: req.user.u, n: req.user.n, a: `Quitó a la mesera ${t.n}` });
  res.json({ ok: true });
}));

/* ---------- Archivos de la página ---------- */
app.get('/config.js', (q, s) => s.type('js').send("window.APP_CONFIG={API:'/api'};"));
for (const f of ['styles.css', 'app.js']) app.get('/' + f, (q, s) => s.sendFile(path.join(ROOT, f)));
app.get('/', (q, s) => s.sendFile(path.join(ROOT, 'index.html')));
app.use('/assets', express.static(path.join(ROOT, 'assets'), { maxAge: '1d', dotfiles: 'deny' }));
app.use('/api', (q, s) => s.status(404).json({ error: 'Ruta no encontrada' }));

app.use((err, req, res, next) => {
  if (err.type === 'entity.too.large') err = http(413, 'La solicitud es demasiado grande');
  if (err.type === 'entity.parse.failed') err = http(400, 'Solicitud mal formada');
  const status = err.status || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ error: status >= 500 ? 'Error del servidor' : err.message });
});

/* ---------- Arranque ---------- */
async function seedIfEmpty() {
  if (!(await store.get('cfg', 'cfg'))) {
    const seed = require('./seed.json'), t = Date.now();
    for (const e of ['platos', 'extras']) for (const o of seed[e]) await store.upsert(e, o.id, o, t);
    for (const k of Object.keys(seed.ins)) await store.upsert('ins', k, seed.ins[k], t);
    await store.upsert('cfg', 'cfg', seed.cfg, t);
    await store.upsert('sub', 'sub', { on: 1, hasta: t + 365 * 864e5 }, t);
    console.log('✔ Datos iniciales (menú, extras, inventario y ajustes) cargados.');
  }
  if ((await store.countUsers()) === 0) {
    const need = ['DEV_USER', 'DEV_PASS', 'ADMIN_USER', 'ADMIN_PASS'].filter(k => !process.env[k]);
    if (need.length) throw new Error('Primer arranque: define en .env ' + need.join(', ') + ' (usuarios iniciales).');
    const dev = cleanUser({ u: process.env.DEV_USER, n: 'Desarrollador', p: process.env.DEV_PASS }, { needPass: true });
    const adm = cleanUser({ u: process.env.ADMIN_USER, n: 'Cocina', p: process.env.ADMIN_PASS }, { needPass: true });
    if (dev.u === adm.u) throw new Error('DEV_USER y ADMIN_USER deben ser distintos.');
    await store.addUser({ u: dev.u, n: dev.n, r: 'x', h: await hashPw(dev.p) });
    await store.addUser({ u: adm.u, n: adm.n, r: 'a', h: await hashPw(adm.p) });
    console.log('✔ Usuarios iniciales creados (desarrollador y cocina). Ya puedes borrar las contraseñas de .env.');
  }
}

(async () => {
  if ((process.env.STORE || 'mssql') === 'memory') {
    store = await require('./store-memory')();
    console.log('⚠ Modo DEMO: los datos viven en memoria y se pierden al apagar el servidor.');
  } else {
    store = await require('./store-mssql')({
      server: process.env.DB_SERVER || 'localhost', port: +process.env.DB_PORT || 1433, database: process.env.DB_NAME || 'Alcipizza',
      user: process.env.DB_USER, password: process.env.DB_PASSWORD,
      options: { encrypt: process.env.DB_ENCRYPT === 'true', trustServerCertificate: process.env.DB_TRUST_CERT !== 'false' },
      pool: { max: 10, min: 0, idleTimeoutMillis: 30000 }, requestTimeout: 30000
    });
  }
  await store.init();
  await seedIfEmpty();
  app.listen(PORT, () => console.log(`✔ Alcipizza listo en http://localhost:${PORT}  (almacén: ${store.kind})`));
})().catch(e => { console.error('✖ No se pudo iniciar:', e.message); process.exit(1); });
