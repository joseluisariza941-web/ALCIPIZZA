'use strict';
// Almacén real sobre SQL Server (paquete "mssql").
const fs = require('fs');
const path = require('path');
const ENT = require('./entities');

module.exports = async function mssqlStore(cfg, sql = require('mssql')) {
  // Tipos de parámetros
  const TY = {
    nv: l => sql.NVarChar(l), dec: () => sql.Decimal(18, 2), dec3: () => sql.Decimal(18, 3), dt: () => sql.DateTime2(3)
  };
  const KT = { big: () => sql.BigInt, int: () => sql.Int, nv: () => sql.NVarChar(200) };
  const MAX = () => sql.NVarChar(sql.MAX);

  // 1) Crear la base de datos si no existe (necesita permiso); si falla, se asume que ya existe.
  if (!/^[A-Za-z0-9_]+$/.test(cfg.database)) throw new Error('DB_NAME solo puede tener letras, números y _');
  try {
    const m = await new sql.ConnectionPool({ ...cfg, database: 'master' }).connect();
    await m.request().input('n', sql.NVarChar(128), cfg.database).query(
      "IF DB_ID(@n) IS NULL BEGIN DECLARE @s NVARCHAR(300) = N'CREATE DATABASE ' + QUOTENAME(@n); EXEC(@s); END");
    await m.close();
  } catch (e) { /* sin permisos: la base debe existir */ }

  const pool = await new sql.ConnectionPool(cfg).connect();
  const rq = tx => (tx ? new sql.Request(tx) : pool.request());
  const mapUser = r => r && ({ id: r.Id, u: r.Usuario, n: r.Nombre, r: r.Rol, h: r.ClaveHash, v: Number(r.Actualizado) });
  const dupErr = e => (e && (e.number === 2627 || e.number === 2601)) ? Object.assign(new Error('dup'), { dup: true }) : e;

  return {
    kind: 'SQL Server',

    async init() {
      const txt = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
      for (const b of txt.split(/^\s*GO\s*$/im).map(s => s.trim()).filter(Boolean)) await pool.request().batch(b);
    },

    async tx(fn) {
      const t = new sql.Transaction(pool);
      await t.begin();
      try { const r = await fn(t); await t.commit(); return r; } catch (e) { try { await t.rollback(); } catch (_) {} throw e; }
    },

    async list(e, since = 0, tx) {
      const d = ENT[e], r = rq(tx);
      r.input('s', sql.BigInt, since);
      let w = 'Actualizado > @s';
      if (d.fixed) { r.input('f', sql.NVarChar(40), d.fixed); w += ` AND [${d.k}] = @f`; }
      const top = d.lim && since === 0 ? `TOP (${+d.lim}) ` : '';
      const order = top ? ' ORDER BY Actualizado DESC' : '';
      const x = await r.query(`SELECT ${top}[${d.k}] AS k, Datos AS d FROM dbo.[${d.t}] WHERE ${w}${order}`);
      return x.recordset.map(o => ({ k: String(o.k), d: JSON.parse(o.d) }));
    },

    async get(e, k, tx) {
      const d = ENT[e], r = rq(tx);
      r.input('k', KT[d.kt](), d.fixed ? d.fixed : k);
      const x = await r.query(`SELECT Datos AS d FROM dbo.[${d.t}] WHERE [${d.k}] = @k`);
      return x.recordset[0] ? JSON.parse(x.recordset[0].d) : null;
    },

    // Inserta o actualiza una fila (patrón UPDATE + INSERT con bloqueo) y quita su "tumba" si existía.
    async upsert(e, k, obj, t, tx) {
      const d = ENT[e], cols = d.c(obj), r = rq(tx), names = Object.keys(cols);
      const key = d.fixed ? d.fixed : k;
      r.input('k', KT[d.kt](), key);
      r.input('d', MAX(), JSON.stringify(obj));
      r.input('t', sql.BigInt, t);
      r.input('e', sql.NVarChar(20), e);
      r.input('kk', sql.NVarChar(200), String(key));
      names.forEach((n, i) => { const [v, ty, len] = cols[n]; r.input('c' + i, TY[ty](len), v); });
      const set = [...names.map((n, i) => `[${n}] = @c${i}`), 'Datos = @d', 'Actualizado = @t'].join(', ');
      const cn = [d.k, ...names, 'Datos', 'Actualizado'].map(x => `[${x}]`).join(', ');
      const cv = ['@k', ...names.map((n, i) => '@c' + i), '@d', '@t'].join(', ');
      await r.query(
        `UPDATE dbo.[${d.t}] WITH (UPDLOCK, SERIALIZABLE) SET ${set} WHERE [${d.k}] = @k;\n` +
        `IF @@ROWCOUNT = 0 INSERT INTO dbo.[${d.t}] (${cn}) VALUES (${cv});\n` +
        `DELETE FROM dbo.Eliminados WHERE Entidad = @e AND Clave = @kk;`);
    },

    async del(e, k, t, tx) {
      const d = ENT[e], r = rq(tx);
      r.input('k', KT[d.kt](), k);
      r.input('t', sql.BigInt, t);
      r.input('e', sql.NVarChar(20), e);
      r.input('kk', sql.NVarChar(200), String(k));
      await r.query(
        `DELETE FROM dbo.[${d.t}] WHERE [${d.k}] = @k;\n` +
        `UPDATE dbo.Eliminados SET Fecha = @t WHERE Entidad = @e AND Clave = @kk;\n` +
        `IF @@ROWCOUNT = 0 INSERT INTO dbo.Eliminados (Entidad, Clave, Fecha) VALUES (@e, @kk, @t);`);
    },

    async tombs(since = 0) {
      const x = await pool.request().input('s', sql.BigInt, since)
        .query('SELECT Entidad AS e, Clave AS k FROM dbo.Eliminados WHERE Fecha > @s');
      return x.recordset.map(o => ({ e: o.e, k: o.k }));
    },

    async nextId() {
      const x = await pool.request().query('SELECT NEXT VALUE FOR dbo.SeqPedido AS id');
      return x.recordset[0].id;
    },

    // ----- Usuarios -----
    async countUsers() { return (await pool.request().query('SELECT COUNT(*) AS n FROM dbo.Usuarios')).recordset[0].n; },
    async userById(id) {
      return mapUser((await pool.request().input('i', sql.Int, +id)
        .query('SELECT Id, Usuario, Nombre, Rol, ClaveHash, Actualizado FROM dbo.Usuarios WHERE Id = @i')).recordset[0]);
    },
    async userByName(u) {
      return mapUser((await pool.request().input('u', sql.NVarChar(50), u)
        .query('SELECT Id, Usuario, Nombre, Rol, ClaveHash, Actualizado FROM dbo.Usuarios WHERE Usuario = @u')).recordset[0]);
    },
    async users() {
      const x = await pool.request().query('SELECT Id, Usuario, Nombre, Rol, ClaveHash, Actualizado FROM dbo.Usuarios ORDER BY Rol DESC, Nombre');
      return x.recordset.map(mapUser).map(({ h, ...u }) => u);
    },
    async addUser({ u, n, r, h }) {
      try {
        const x = await pool.request()
          .input('u', sql.NVarChar(50), u).input('n', sql.NVarChar(80), n).input('r', sql.NVarChar(1), r)
          .input('h', sql.NVarChar(300), h).input('t', sql.BigInt, Date.now())
          .query('INSERT INTO dbo.Usuarios (Usuario, Nombre, Rol, ClaveHash, Actualizado) VALUES (@u, @n, @r, @h, @t); SELECT CAST(SCOPE_IDENTITY() AS INT) AS id;');
        return x.recordset[0].id;
      } catch (e) { throw dupErr(e); }
    },
    async setUser(id, { u, n, h }) {
      const r = pool.request().input('i', sql.Int, +id).input('t', sql.BigInt, Date.now() + Math.floor(Math.random() * 1000));
      const set = ['Actualizado = @t'];
      if (u) { r.input('u', sql.NVarChar(50), u); set.push('Usuario = @u'); }
      if (n) { r.input('n', sql.NVarChar(80), n); set.push('Nombre = @n'); }
      if (h) { r.input('h', sql.NVarChar(300), h); set.push('ClaveHash = @h'); }
      try { await r.query(`UPDATE dbo.Usuarios SET ${set.join(', ')} WHERE Id = @i`); } catch (e) { throw dupErr(e); }
    },
    async delUser(id) { await pool.request().input('i', sql.Int, +id).query('DELETE FROM dbo.Usuarios WHERE Id = @i'); }
  };
};
