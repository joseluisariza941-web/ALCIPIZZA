'use strict';
// Descripción de cada "entidad" de la aplicación y de su tabla en SQL Server.
//  t: tabla · k: columna clave · kt: tipo de la clave · fixed: clave fija (tabla Config)
//  c(obj): columnas consultables [valor, tipo, longitud]. La fila completa se guarda siempre en "Datos".
const nv = (v, l) => [v == null || v === '' ? null : String(v).slice(0, l), 'nv', l];
const num = (v, t) => [v == null || Number.isNaN(+v) ? null : +v, t];
const fecha = v => [v ? new Date(v) : null, 'dt'];

module.exports = {
  platos:  { t: 'Platos', k: 'Id', kt: 'big', c: o => ({ Nombre: nv(o.n, 120), Categoria: nv(o.c, 60) }) },
  extras:  { t: 'Extras', k: 'Id', kt: 'big', c: o => ({ Nombre: nv(o.n, 120), Insumo: nv(o.ins, 120), Precio: num(o.p, 'dec') }) },
  ins:     { t: 'Insumos', k: 'Nombre', kt: 'nv', c: o => ({ Tipo: nv(o.k, 1), Unidad: nv(o.u, 10), Stock: num(o.s, 'dec3'), Surtidor: nv(o.sur, 40) }) },
  sur:     { t: 'Surtidores', k: 'Id', kt: 'big', c: o => ({ Nombre: nv(o.n, 120), Empresa: nv(o.emp, 120), Correo: nv(o.mail, 120), Telefono: nv(o.tel, 40) }) },
  compras: { t: 'Compras', k: 'Clave', kt: 'nv', c: o => ({ Fecha: fecha(o.t), Producto: nv(o.n, 120), Cantidad: num(o.q, 'dec3'), Unidad: nv(o.u, 10), Costo: num(o.v, 'dec'), Surtidor: nv(o.sur, 40), Registro: nv(o.by, 80) }) },
  pedidos: { t: 'Pedidos', k: 'Id', kt: 'int', lim: 0, c: o => ({ Fecha: fecha(o.t), Origen: nv(o.o, 10), Mesera: nv(o.m, 50), Destino: nv(o.d, 100), Cliente: nv(o.nom, 100), Telefono: nv(o.tel, 30), Total: num(o.tot, 'dec'), Estado: nv(o.est, 20), PagoEstado: nv(o.pg, 20), MetodoPago: nv(o.mp, 60), Token: nv(o.tk, 60) }) },
  logs:    { t: 'Bitacora', k: 'Clave', kt: 'nv', lim: 500, c: o => ({ Fecha: fecha(o.t), Usuario: nv(o.u, 50), Nombre: nv(o.n, 80), Accion: nv(o.a, 400) }) },
  cfg:     { t: 'Config', k: 'Clave', kt: 'nv', fixed: 'cfg', c: () => ({}) },
  sub:     { t: 'Config', k: 'Clave', kt: 'nv', fixed: 'sub', c: () => ({}) }
};
